# Aakarsh Sangar Personal Site

This is a static personal portfolio site.

## Publish Free With GitHub Pages

You do not need to buy a domain. GitHub Pages can host this site at a free URL like:

`https://aakarsh-s.github.io/portfolio/`

Recommended setup:

1. Create a GitHub repository, for example `portfolio`.
2. Upload the contents of this `personal-site` folder to that repository.
3. In GitHub, open the repository settings.
4. Go to `Pages`.
5. Under `Build and deployment`, choose `Deploy from a branch`.
6. Choose the `main` branch and `/ (root)` folder.
7. Save. GitHub will give you the live Pages URL.

Because the site uses relative paths like `./styles.css` and `./projects.json`, it works on GitHub Pages whether the repository is named `portfolio` or `aakarsh-s.github.io`.

## Add a Project

1. Put the project image in `assets/projects/`.
2. Find that project in `projects.json`.
3. Add a relative image path such as `./assets/projects/my-project.png`.
4. Add the real GitHub URL to `github`.
5. Add a CAD, demo, paper, or writeup URL to `docs` when useful.

Example:

```json
{
  "title": "Project Name",
  "featured": true,
  "category": "Robotics",
  "status": "2026",
  "description": "One or two sentences about what it does.",
  "github": "https://github.com/username/repo",
  "docs": "https://example.com/project-writeup",
  "docsLabel": "Writeup",
  "image": "./assets/projects/project-name.png",
  "imageAlt": "Screenshot of Project Name",
  "tags": ["React", "AI", "Tools"]
}
```

For multiple project images, use `images` instead of `image`:

```json
"images": [
  {
    "src": "./assets/projects/main-screenshot.png",
    "alt": "Main project screenshot"
  },
  {
    "src": "./assets/projects/detail-screenshot.png",
    "alt": "Supporting project screenshot"
  }
]
```

Current project slots are based on the CV template:

- Custom Robotic Arm
- Jetson Orin Nano Robotics Platform
- Faultline
- Vision-Based Health Monitoring System
- ModalAI Robotics Internship
- FIRST / FTC Robotics
- CalHacks AI Hackathon
- TritonHacks
- Science Olympiad Coaching

## Optional Custom Domain

A custom domain can be added later, but it is not required.
